<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2019-12-06T14:48:59</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>071c0a1c-5edc-4613-b515-9c2c8abd3bd5</testSuiteGuid>
   <testCaseLink>
      <guid>02cae663-b40b-42ed-85ef-d02a0371e540</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Login1</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
