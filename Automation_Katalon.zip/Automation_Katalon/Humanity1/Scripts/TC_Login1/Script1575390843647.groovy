import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.testdata.ExcelData
import com.kms.katalon.core.testobject.ConditionType

import com.kms.katalon.core.testdata.InternalData

// Data driven test - copy Use cases from Excel table
ExcelData data = findTestData('TestData_Login')

for (def index : (0..data.getRowNumbers() - 1)) {
	

WebUI.openBrowser('')

WebUI.navigateToUrl('https://dsgroup.humanity.com/app/')

WebUI.setText(findTestObject('Object Repository/Page_Online Employee Scheduling Sof/input_Your password has expire'), data.internallyGetValue('Username', index)) // 'dragan@dplussgroup.com')

//WebUI.setEncryptedText(findTestObject('Object Repository/Page_Online Employee Scheduling Sof/input_Your password has expire_9'), '7yNAhyZfJovLPv5wBPwDxw==')
// DS Use explicit pswd for Auto TCs 
WebUI.setText(findTestObject('Object Repository/Page_Online Employee Scheduling Sof/input_Your password has expire_9'), data.internallyGetValue('Password', index))  //	'Testab12')

WebUI.click(findTestObject('Object Repository/Page_Online Employee Scheduling Sof/button_Log in'))

WebUI.delay(3)

boolean found = false
TestObject to
to = new TestObject().addProperty('xpath', ConditionType.CONTAINS, '//input[@id="password"]')

found = WebUI.verifyElementAttributeValue(to, "title", "Password", 10, FailureHandling.CONTINUE_ON_FAILURE)

WebUI.delay(3)

String tcType = data.internallyGetValue('TCType', index)

boolean isPositive = tcType.contentEquals("PositiveTC")

if (!found && isPositive)  // if expected Login to succeed 
{
	//Mark Passed status after this step
	KeywordUtil.markPassed("Login Success")
	
	// Click on Profile to sign out
	WebUI.click(findTestObject('Object Repository/Page_Dashboard - Dashboard - Humani/i_dashboard_icon icon-arrowFul'))
	
	// DS Do sign out
	WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Dashboard - Dashboard - Humani/a_Sign Out'), 10)
	WebUI.click(findTestObject('Object Repository/Page_Dashboard - Dashboard - Humani/a_Sign Out'))

}
else  if (found &&  !isPositive)  // if expected Login to fail  
{
	//Mark Passed status after this step
	KeywordUtil.markPassed("Login Success")
}
else {  // everething else TC step failed  
    //Mark Failed status after this step
     KeywordUtil.markFailed("Login Error for TC row = " + (index+1) )
}

WebUI.delay(3)


// DS Close browser 
WebUI.closeBrowser()
}
