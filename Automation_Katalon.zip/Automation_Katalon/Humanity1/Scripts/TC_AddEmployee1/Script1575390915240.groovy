import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.util.KeywordUtil


WebUI.openBrowser('')

WebUI.navigateToUrl('https://dsgroup.humanity.com/app/')

WebUI.setText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire'), 'dragan@dplussgroup.com')

/*

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_1'), 'UjWHzyF6vE8=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_2'), 'LweSLJQTg+o=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_3'), 'igsYPd+nmTw=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_4'), 'dU0VtZoHC6c=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_5'), 'owxJb57zlZM=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_6'), 'NTWmetTTtYI=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_7'), 'NHVSWWF9gS8=')

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_8'), '7yNAhyZfJovLPv5wBPwDxw==')
*/

WebUI.setEncryptedText(findTestObject('Page_Online Employee Scheduling Sof/input_Your password has expire_9'), '7yNAhyZfJovLPv5wBPwDxw==')
// DS Use explicit pswd for Auto TCs
WebUI.setText(findTestObject('Object Repository/Page_Online Employee Scheduling Sof/input_Your password has expire_9'), 'Testab12')


WebUI.click(findTestObject('Page_Online Employee Scheduling Sof/button_Log in'))

//if (!WebUI.verifyElementPresent('Object Repository/Page_Dashboard - Dashboard - Humani/i_dashboard_primNavQtip__icon', 5))
//	WebUI.mark_TC_failed
//WebUI.verifyElementVisible('Object Repository/Page_Dashboard - Dashboard - Humani/i_dashboard_primNavQtip__icon')

WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Dashboard - Dashboard - Humani/i_dashboard_primNavQtip__icon'), 10)
WebUI.click(findTestObject('Object Repository/Page_Dashboard - Dashboard - Humani/i_dashboard_primNavQtip__icon'))

WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Staff - List - Humanity/button_Add Employees'), 10)
WebUI.click(findTestObject('Object Repository/Page_Staff - List - Humanity/button_Add Employees'))

// DS This data should be taken from data file ( data-driven) , similarly to Login TC  
// Note: Email must be unique to add a New Employee
WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__asf1'), 10)
WebUI.setText(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__asf1'), 'First1A')

WebUI.setText(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__asl1'), 'Last1A')

WebUI.setText(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__ase1'), 'firstAB@lastC.com')

//WebUI.setText(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__asf2'), 'First2B')
//
//WebUI.setText(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__asl2'), 'Last2B')
//
//WebUI.setText(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/input_Email__ase2'), 'first2B@last2B.com')

// DS comment during unit tesing of the script out to avoid unnecessary new records 
WebUI.click(findTestObject('Object Repository/Page_Staff - Add Staff - Humanity/button_Save Employees'))

WebUI.click(findTestObject('Object Repository/Page_Staff - Assignstaffnew1first52/i_Staff_icon icon-arrowFullDn'))

// DS Do sign out
WebUI.waitForElementVisible(findTestObject('Object Repository/Page_Staff - Assignstaffnew1first52/a_Sign Out'), 10)
WebUI.click(findTestObject('Object Repository/Page_Staff - Assignstaffnew1first52/a_Sign Out'))


WebUI.closeBrowser()

